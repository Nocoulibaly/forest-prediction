# Prédiction du type de couverture forestière

## Aperçu du projet

Ce projet prédit les types de couverture forestière à l'aide de données cartographiques. L'objectif est de classer les catégories de forêts aussi précisément que possible en utilisant l'apprentissage automatique.

## Caractéristiques

- **Distance_To_Hydrologie** :
 Distances horizontales et verticales combinées.

- **Distance_de_la_route_de_l'incendie** : 
Différence entre les distances entre les points d'incendie et les routes.
- Interaction avec l'altitude des pentes** : Terme d'interaction pour capturer les variations de terrain.

## Étapes de mise en œuvre

1. **Prétraitement:**
 Nettoyage des données, mise à l'échelle et ingénierie des caractéristiques.

2. **Entraînement du modèle:** 
Recherche de grille sur 5 modèles (Random Forest, Gradient Boosting, SVM, KNN, Régression logistique).

3. **Évaluation:**
 Précision des tests (> 0,65), courbes d'apprentissage et matrice de confusion.

## Résultats

- Meilleur modèle:** Random Forest
- Précision de la validation:** 0.89
- Précision du test:** 0.67
- Les courbes d'apprentissage et la matrice de confusion sont sauvegardées dans le répertoire `results/`.

## Comment exécuter

1. Installez les dépendances :
  `` conda env create -f environment.yml ``
  `` conda activate forest-prediction ``
   

2. Prétraiter les données :
``python scripts/preprocessing_feature_engineering.py``

3. Modèles de trains :
``python scripts/model_selection.py``

4. Faire des prédictions :
``python scripts/predict.py``

## Auteur
Nocoulibaly