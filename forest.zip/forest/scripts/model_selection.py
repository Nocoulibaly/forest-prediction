import os
import pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.metrics import confusion_matrix, classification_report
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import learning_curve


def load_preprocessed_data(file_path):
    """Charge les données prétraitées."""
    return pd.read_csv(file_path)

def train_and_evaluate(models, param_grids, X_train, y_train, n_splits=5):
    """Entraîne plusieurs modèles avec validation croisée et recherche par grille."""
    best_model = None
    best_score = 0
    best_params = {}
    
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    
    for model_name, model in models.items():
        print(f"Entraînement du modèle : {model_name}")
        grid = GridSearchCV(model, param_grids[model_name], cv=cv, scoring='accuracy', n_jobs=-1)
        grid.fit(X_train, y_train)
        
        print(f"Meilleur score pour {model_name} : {grid.best_score_}")
        print(f"Meilleurs paramètres : {grid.best_params_}")
        
        if grid.best_score_ > best_score:
            best_score = grid.best_score_
            best_model = grid.best_estimator_
            best_params = grid.best_params_
    
    return best_model, best_score, best_params

def plot_learning_curve(estimator, X, y, cv, output_path):
    """Trace la courbe d'apprentissage pour le meilleur modèle."""
    train_sizes, train_scores, test_scores = learning_curve(estimator, X, y, cv=cv)
    plt.figure()
    plt.plot(train_sizes, train_scores.mean(axis=1), label='Train Score', color='blue')
    plt.plot(train_sizes, test_scores.mean(axis=1), label='Validation Score', color='green')
    plt.xlabel('Training Size')
    plt.ylabel('Accuracy')
    plt.title(f'Learning Curve of {best_model}')
    plt.legend()
    plt.savefig(output_path)
    plt.close()

def save_test_predictions(y_test, y_pred, output_path):
    """Sauvegarde les prédictions et vraies valeurs dans un fichier CSV."""
    predictions = pd.DataFrame({
        'True_Label': y_test,
        'Predicted_Label': y_pred
    })
    predictions.to_csv(output_path, index=False)

if __name__ == "__main__":
    
    # Charger les données
    data = load_preprocessed_data('data/train_preprocessed.csv')
    X = data.drop(columns=['Cover_Type'])
    y = data['Cover_Type']
    
    # Diviser les données en jeu d'entraînement et de test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # Modèles et grilles de paramètres
    models = {
        'RandomForest': RandomForestClassifier(),
        'GradientBoosting': GradientBoostingClassifier(),
        'KNN': KNeighborsClassifier(),
        'SVM': SVC(),
        'LogisticRegression': LogisticRegression(max_iter=500)
    }
    
    param_grids = {
    'RandomForest': {'n_estimators': [100], 'max_depth': [10, None]},
    'GradientBoosting': {'learning_rate': [0.1], 'n_estimators': [100]},
    'KNN': {'n_neighbors': [3, 5]},
    'SVM': {'C': [1, 10], 'kernel': ['rbf']},
    'LogisticRegression': {'C': [1]}
    }

    
    # Entraînement et évaluation
    best_model, best_score, best_params = train_and_evaluate(models, param_grids, X_train, y_train)
    
    # Évaluer sur le jeu de test
    y_test_pred = best_model.predict(X_test)
    print(classification_report(y_test, y_test_pred))
    
    # Sauvegarder la matrice de confusion
    cm = confusion_matrix(y_test, y_test_pred)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.title("Confusion Matrix (Test Set)")
    plt.savefig('results/confusion_matrix_heatmap.png')
    plt.close()
    
    # Sauvegarder la courbe d'apprentissage
    plot_learning_curve(best_model, X, y, cv=5, output_path='results/learning_curve_best_model.png')
    
    # Sauvegarder les prédictions
    save_test_predictions(y_test, y_test_pred, 'results/evaluation_predictions.csv')
    
    # Sauvegarder le meilleur modèle
    with open('results/best_model.pkl', 'wb') as f:
        pickle.dump(best_model, f)
    
    print(f"Meilleur modèle enregistré avec un score de validation de {best_score:.2f} est : {best_model}")
