import os
import pandas as pd
import numpy as np
import logging
from sklearn.preprocessing import StandardScaler

# Configuration du journal
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def load_data(file_path):
    """Charge les données depuis un fichier CSV avec une vérification."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Le fichier {file_path} est introuvable.")
    logging.info(f"Chargement des données depuis {file_path}.")
    return pd.read_csv(file_path)

def create_features(data):
    """Crée de nouvelles fonctionnalités à partir des données existantes."""
    required_columns = [
        'Horizontal_Distance_To_Hydrology', 
        'Vertical_Distance_To_Hydrology', 
        'Horizontal_Distance_To_Fire_Points', 
        'Horizontal_Distance_To_Roadways'
    ]
    for col in required_columns:
        if col not in data.columns:
            raise ValueError(f"La colonne requise '{col}' est absente des données.")
    
    # Distance to hydrology
    data['Distance_To_Hydrology'] = np.sqrt(
        data['Horizontal_Distance_To_Hydrology']**2 + data['Vertical_Distance_To_Hydrology']**2
    )
    
    # Difference between Fire Points and Roadways
    data['Fire_Road_Distance'] = data['Horizontal_Distance_To_Fire_Points'] - data['Horizontal_Distance_To_Roadways']
    logging.info("Création des nouvelles fonctionnalités terminée.")
    
    return data

def preprocess_data(data, scale_features=True):
    """Effectue le prétraitement des données."""
    columns_to_drop = ['Id']  # Remplacez "Id" par les colonnes non nécessaires si besoin
    data = data.drop(columns=columns_to_drop, errors='ignore')
    logging.info(f"Colonnes supprimées : {columns_to_drop}.")
    
    if scale_features:
        continuous_columns = [
            'Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology',
            'Vertical_Distance_To_Hydrology', 'Horizontal_Distance_To_Roadways',
            'Horizontal_Distance_To_Fire_Points', 'Distance_To_Hydrology', 'Fire_Road_Distance'
        ]
        scaler = StandardScaler()
        data[continuous_columns] = scaler.fit_transform(data[continuous_columns])
        logging.info("Normalisation des colonnes continues effectuée.")
    
    return data

def validate_data(data):
    """Valide les données pour détecter les valeurs manquantes."""
    missing = data.isnull().sum()
    if missing.any():
        logging.warning(f"Des valeurs manquantes ont été détectées :\n{missing[missing > 0]}")


def save_preprocessed_data(data, output_path):
    """Enregistre les données prétraitées dans un fichier CSV."""
    try:
        data.to_csv(output_path, index=False)
        logging.info(f"Données enregistrées avec succès dans {output_path}.")
    except Exception as e:
        logging.error(f"Erreur lors de l'enregistrement des données : {e}")

if __name__ == "__main__":
    # Charger les données
    train_data = load_data('data/train.csv')
    
    # Créer des fonctionnalités
    train_data = create_features(train_data)
    
    # Prétraiter les données
    train_data = preprocess_data(train_data)
    
    # Valider les données
    validate_data(train_data)
    
    # Enregistrer les données traitées
    save_preprocessed_data(train_data, 'data/train_preprocessed.csv')
