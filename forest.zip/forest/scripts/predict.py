import pandas as pd
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

def load_model(model_path):
    """Charge un modèle sauvegardé."""
    with open(model_path, 'rb') as f:
        return pickle.load(f)

def load_data(file_path):
    """Charge les données depuis un fichier CSV."""
    return pd.read_csv(file_path)

def align_columns(reference_data, target_data):
    """Harmonise les colonnes entre deux ensembles de données."""
    for col in reference_data.columns:
        if col not in target_data.columns:
            target_data[col] = 0
    return target_data[reference_data.columns]

def evaluate_model(model, X, y):
    """Évalue les performances d'un modèle sur un ensemble de données."""
    predictions = model.predict(X)
    accuracy = accuracy_score(y, predictions)
    conf_matrix = confusion_matrix(y, predictions)
    conf_df = pd.DataFrame(
        conf_matrix,
        index=[f'Vraie_{i+1}' for i in range(len(conf_matrix))],
        columns=[f'Pred_{i+1}' for i in range(len(conf_matrix))]
    )
    return accuracy, conf_df, predictions

def save_predictions(file_path, true_classes, predicted_classes):
    """Sauvegarde les prédictions dans un fichier CSV."""
    results = pd.DataFrame({
        'True_Class': true_classes,
        'Predicted_Class': predicted_classes
    })
    results.to_csv(file_path, index=False)
    print(f"Prédictions sauvegardées dans {file_path}")

def visualize_confusion_matrix(conf_matrix, file_path, title):
    """Visualise une matrice de confusion et l'enregistre."""
    plt.figure(figsize=(10, 8))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
    plt.title(title)
    plt.tight_layout()
    plt.savefig(file_path)
    print(f"Visualisation sauvegardée dans {file_path}")

def main():
    print("Chargement du modèle...")
    model = load_model('results/best_model.pkl')

    print("Chargement des données d'entraînement...")
    train_data = load_data('data/train.csv')
    y_train = train_data.pop('Cover_Type')

    # Harmoniser les colonnes avec le modèle
    print("Harmonisation des colonnes pour l'ensemble d'entraînement...")
    missing_features_train = set(model.feature_names_in_) - set(train_data.columns)
    for feature in missing_features_train:
        train_data[feature] = 0
    X_train = train_data[model.feature_names_in_]

    # Évaluation sur l'ensemble d'entraînement
    print("\nÉvaluation sur l'ensemble d'entraînement...")
    train_accuracy, train_conf_matrix, train_predictions = evaluate_model(model, X_train, y_train)
    print(f"Précision de l'ensemble d'entraînement : {train_accuracy:.3f}")
    print(f"Précision < 0,98 ? {train_accuracy < 0.98}")
    print("Matrice de confusion (entraînement) :\n", train_conf_matrix)

    # Visualisation des résultats d'entraînement
    visualize_confusion_matrix(train_conf_matrix, 'results/confusion_matrix_train.png', 
                               'Matrice de confusion - Données d\'entraînement')

    # Chargement des données de test
    print("\nChargement des données de test...")
    test_data = load_data('data/test.csv')

    if 'Cover_Type' in test_data.columns:
        y_test = test_data.pop('Cover_Type')
        print("Étiquettes de test trouvées.")
    else:
        print("Attention : Les étiquettes de test (Cover_Type) sont manquantes.")
        y_test = None

    # Harmonisation des colonnes pour le test
    print("Harmonisation des colonnes pour l'ensemble de test...")
    X_test = align_columns(X_train, test_data)

    if y_test is not None:
        # Évaluation sur l'ensemble de test
        print("\nÉvaluation sur l'ensemble de test...")
        test_accuracy, test_conf_matrix, test_predictions = evaluate_model(model, X_test, y_test)
        print(f"Précision de l'ensemble de test : {test_accuracy:.3f}")
        print(f"Précision > 0,65 ? {test_accuracy > 0.65}")
        print("Matrice de confusion (test) :\n", test_conf_matrix)

        # Visualisation des résultats de test
        visualize_confusion_matrix(test_conf_matrix, 'results/confusion_matrix_test.png', 
                                   'Matrice de confusion - Données de test')

        # Sauvegarder les prédictions
        save_predictions('data/test_evaluation_results.csv', y_test, test_predictions)
    else:
        # Générer uniquement des prédictions pour les données de test
        print("\nGénération des prédictions pour l'ensemble de test (sans évaluation)...")
        test_predictions = model.predict(X_test)
        save_predictions('data/test_predictions.csv', None, test_predictions)

    # Statistiques supplémentaires
    print("\nStatistiques des prédictions (entraînement) :")
    print(pd.Series(train_predictions).value_counts().sort_index())

    if y_test is not None:
        print("\nStatistiques des prédictions (test) :")
        print(pd.Series(test_predictions).value_counts().sort_index())

if __name__ == "__main__":
    main()
